set @questionCount := (Select COUNT(*) from Questions);

set @scoreMedian := (Select score FROM Questions ORDER BY score LIMIT 1 OFFSET 29578);
set @viewMedian := (Select viewCount FROM Questions ORDER BY viewCount LIMIT 1 OFFSET 29578);
set @answerMedian := (Select answerCount FROM Questions ORDER BY answerCount LIMIT 1 OFFSET 29578);
set @favoriteMedian := (Select favoriteCount FROM Questions ORDER BY favoriteCount LIMIT 1 OFFSET 29578);
set @commentMedian := (Select commentCount FROM Questions ORDER BY commentCount LIMIT 1 OFFSET 29578);

Select 
@questionCount as NumberOfQuestions,
AVG(score) as AverageScore,
stddev(score) as StdDevScore,
@scoreMedian as MedianScore,

AVG(viewCount) as AverageViewCount,
stddev(viewCount) as StdDevViewCount,
@viewMedian as MedianViewCount,

AVG(answerCount) as AverageAnswerCount,
stddev(answerCount) as StdDevAnswerCount,
@answerMedian as MedianAnswerCount,

AVG(commentCount) as AverageCommentCount,
stddev(commentCount) as StdDevCommentCount,
@commentMedian as MedianCommentCount,

AVG(favoriteCount) as AverageFavoriteCount,
stddev(favoriteCount) as StdDevFavoriteCount,
@favoriteMedian as MedianFavoriteCount,

count(id_selected_answer)/@questionCount as SelectedAnswerRate

FROM Questions