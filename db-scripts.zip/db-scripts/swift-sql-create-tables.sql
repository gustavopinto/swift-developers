DROP TABLE IF EXISTS Comments;
DROP TABLE IF EXISTS AnswerTopics;
DROP TABLE IF EXISTS QuestionTopics;
DROP TABLE IF EXISTS Answers;
DROP TABLE IF EXISTS Questions;
DROP TABLE IF EXISTS Users;
DROP TABLE IF EXISTS Topics;


CREATE TABLE Topics (
  id_topic INTEGER NOT NULL,
  name TEXT NULL,
  words TEXT NULL,
  PRIMARY KEY(id_topic)
);

CREATE TABLE Users (
  id_user INTEGER NOT NULL,
  reputation INTEGER NULL,
  creationDate DATETIME  NULL,
  location TEXT NULL,
  age INTEGER NULL,
  upVotes INTEGER NULL,
  downVotes INTEGER NULL,
  PRIMARY KEY(id_user)
);

CREATE TABLE Questions (
  id_question INTEGER NOT NULL,
  id_user INTEGER NOT NULL,
  id_selected_answer INTEGER NULL,
  titleText TEXT NULL,
  bodyText TEXT NULL,
  processedBody TEXT NULL,
  creationDate DATETIME  NULL,
  score INTEGER NULL,
  viewCount INTEGER NULL,
  answerCount INTEGER NULL,
  commentCount INTEGER NULL,
  favoriteCount INTEGER NULL,
  tags TEXT NULL,
  PRIMARY KEY(id_question),
  FOREIGN KEY (id_user) REFERENCES Users(id_user)
);

CREATE TABLE Answers (
  id_answer INTEGER NOT NULL,
  id_user INTEGER NOT NULL,
  id_question INTEGER NOT NULL,
  bodyText TEXT NULL,
  processedBody TEXT NULL,
  creationDate DATETIME  NULL,
  score INTEGER NULL,
  commentCount INTEGER NULL,
  favoriteCount INTEGER NULL,
  PRIMARY KEY(id_answer),
  FOREIGN KEY (id_question) REFERENCES Questions(id_question),
  FOREIGN KEY (id_user) REFERENCES Users(id_user)
);

CREATE TABLE QuestionTopics (
  id_topic INTEGER NOT NULL,
  id_question INTEGER NOT NULL,
  value DOUBLE NULL,
  PRIMARY KEY(id_topic, id_question),
  FOREIGN KEY (id_question) REFERENCES Questions(id_question),
  FOREIGN KEY (id_topic) REFERENCES Topics(id_topic)
);

CREATE TABLE AnswerTopics (
  id_topic INTEGER NOT NULL,
  id_answer INTEGER NOT NULL,
  value TEXT NULL,
  PRIMARY KEY(id_topic, id_answer),
  FOREIGN KEY (id_answer) REFERENCES Answers(id_answer),
  FOREIGN KEY (id_topic) REFERENCES Topics(id_topic)
);

CREATE TABLE Comments (
  id_comment INTEGER NOT NULL,
  id_user INTEGER NULL,
  id_question INTEGER NULL,
  id_answer INTEGER NULL,
  score INTEGER NULL,
  text TEXT NULL,
  creationDate DATETIME  NULL,
  PRIMARY KEY(id_comment),
  FOREIGN KEY (id_user) REFERENCES Users(id_user),
  FOREIGN KEY (id_question) REFERENCES Questions(id_question),
  FOREIGN KEY (id_answer) REFERENCES Answers(id_answer)
);




