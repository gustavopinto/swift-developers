Script order: (tested with MySQL Workbench 6.3 CE)

1. swift-sql-create
2. swift-users
3. swift-topics-hyper
4. swift-questions
5. swift-answers
6. swift-questions-topics-hyper
7. swift-comments1
8. swift-comments2

9. swift-named_topics-hyper

10. swift-update_named_topics-hyper

